-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 20-12-2016 a las 19:28:39
-- Versión del servidor: 10.1.16-MariaDB
-- Versión de PHP: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `2016hweb`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auth_assignment`
--

CREATE TABLE `auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auth_item`
--

CREATE TABLE `auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`) VALUES
('administrador', 1, NULL, NULL, NULL, 1481732233, 1481732233),
('usuario', 1, NULL, NULL, NULL, 1481732233, 1481732233);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auth_item_child`
--

CREATE TABLE `auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auth_rule`
--

CREATE TABLE `auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migration`
--

CREATE TABLE `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1481730281),
('m140506_102106_rbac_init', 1481730490);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productostbl`
--

CREATE TABLE `productostbl` (
  `id` int(11) NOT NULL,
  `producto` varchar(45) NOT NULL,
  `descripcion` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `productostbl`
--

INSERT INTO `productostbl` (`id`, `producto`, `descripcion`) VALUES
(1, 'papa', 'para hacer pure'),
(2, 'sall', 'para colocar a las comidas'),
(3, 'espinacas', 'verdura');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `puntuaciontbl`
--

CREATE TABLE `puntuaciontbl` (
  `id` int(11) NOT NULL,
  `valoracion` int(11) NOT NULL,
  `usuariostbl_id` int(11) NOT NULL,
  `recetastbl_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `puntuaciontbl`
--

INSERT INTO `puntuaciontbl` (`id`, `valoracion`, `usuariostbl_id`, `recetastbl_id`) VALUES
(1, 1, 3, 1),
(2, 2, 3, 2),
(3, 1, 2, 1),
(4, 5, 3, 6),
(5, 4, 2, 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recetasproducto`
--

CREATE TABLE `recetasproducto` (
  `id` int(11) NOT NULL,
  `recetastbl_id` int(11) NOT NULL,
  `productostbl_id` int(11) NOT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `unidad` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `recetasproducto`
--

INSERT INTO `recetasproducto` (`id`, `recetastbl_id`, `productostbl_id`, `cantidad`, `unidad`) VALUES
(1, 8, 3, 11, 'unidad'),
(2, 8, 2, 22, 'gramos'),
(3, 8, 1, 11, 'kilo'),
(4, 8, 3, 5, 'unidades');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recetastbl`
--

CREATE TABLE `recetastbl` (
  `id` int(11) NOT NULL,
  `receta` varchar(45) NOT NULL,
  `descripcion` varchar(200) DEFAULT NULL,
  `preparacion` varchar(1000) DEFAULT NULL,
  `usuariostbl_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `recetastbl`
--

INSERT INTO `recetastbl` (`id`, `receta`, `descripcion`, `preparacion`, `usuariostbl_id`) VALUES
(1, 'receta1', 'es genial para 5 personas', 'lo preparas, cocinas 5 minutos y listo.', 4),
(2, 'receta2', 'para unas 7 personas', 'espinacas + papas picas  y sal', 4),
(3, 'receta3', 'test3', 'test3', 4),
(5, 'borrame', 'asdasd', 'fasdfasd', 4),
(6, 'recetauser3', 'asdasf', 'asdafasd', 3),
(8, 'receta8', 'receta de prueba 8', 'preparacion de prueba 8', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rolestbl`
--

CREATE TABLE `rolestbl` (
  `id` int(11) NOT NULL,
  `rol` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `rolestbl`
--

INSERT INTO `rolestbl` (`id`, `rol`) VALUES
(1, 'administrador'),
(2, 'usuario');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuariostbl`
--

CREATE TABLE `usuariostbl` (
  `id` int(11) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(70) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `apellido` varchar(45) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `rolestbl_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuariostbl`
--

INSERT INTO `usuariostbl` (`id`, `username`, `password`, `nombre`, `apellido`, `email`, `rolestbl_id`) VALUES
(1, 'usuario1', 'd8e0fd621f8745ab21c9c7de66778d00d9d41b2e2682a5fbc5bff87361c47102', 'usuario uno', 'apellido1', NULL, 2),
(2, 'usuario2', '534063df44e5903915d9ae79265073e51d5f21950b3af1102029378cce270f8a', 'usuario dos', 'apellido2', 'usu2ape2@test.com', 2),
(3, 'usuario3', '15676680ffc67a48761517e72a60827e471fb3ce472862592ed25ce6a7e63a74', 'usuario tres3', 'apellido3', 'usu3ape3@test.com', 2),
(4, 'admin1', '25f43b1486ad95a1398e3eeb3d83bc4010015fcc9bedb35b432e00298d5021f7', 'administrador uno', 'apellido1', 'admin@test.com', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD PRIMARY KEY (`item_name`,`user_id`);

--
-- Indices de la tabla `auth_item`
--
ALTER TABLE `auth_item`
  ADD PRIMARY KEY (`name`),
  ADD KEY `rule_name` (`rule_name`),
  ADD KEY `idx-auth_item-type` (`type`);

--
-- Indices de la tabla `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD PRIMARY KEY (`parent`,`child`),
  ADD KEY `child` (`child`);

--
-- Indices de la tabla `auth_rule`
--
ALTER TABLE `auth_rule`
  ADD PRIMARY KEY (`name`);

--
-- Indices de la tabla `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Indices de la tabla `productostbl`
--
ALTER TABLE `productostbl`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `puntuaciontbl`
--
ALTER TABLE `puntuaciontbl`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_puntuaciontbl_usuariostbl1_idx` (`usuariostbl_id`),
  ADD KEY `fk_puntuaciontbl_recetastbl1_idx` (`recetastbl_id`);

--
-- Indices de la tabla `recetasproducto`
--
ALTER TABLE `recetasproducto`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_recetasproducto_recetastbl1_idx` (`recetastbl_id`),
  ADD KEY `fk_recetasproducto_productostbl1_idx` (`productostbl_id`);

--
-- Indices de la tabla `recetastbl`
--
ALTER TABLE `recetastbl`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_recetastbl_usuariostbl1_idx` (`usuariostbl_id`);

--
-- Indices de la tabla `rolestbl`
--
ALTER TABLE `rolestbl`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuariostbl`
--
ALTER TABLE `usuariostbl`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_usuariostbl_rolestbl1_idx` (`rolestbl_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `productostbl`
--
ALTER TABLE `productostbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `puntuaciontbl`
--
ALTER TABLE `puntuaciontbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `recetasproducto`
--
ALTER TABLE `recetasproducto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `recetastbl`
--
ALTER TABLE `recetastbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT de la tabla `rolestbl`
--
ALTER TABLE `rolestbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `usuariostbl`
--
ALTER TABLE `usuariostbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `auth_item`
--
ALTER TABLE `auth_item`
  ADD CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `puntuaciontbl`
--
ALTER TABLE `puntuaciontbl`
  ADD CONSTRAINT `fk_puntuaciontbl_recetastbl1` FOREIGN KEY (`recetastbl_id`) REFERENCES `recetastbl` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_puntuaciontbl_usuariostbl1` FOREIGN KEY (`usuariostbl_id`) REFERENCES `usuariostbl` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `recetasproducto`
--
ALTER TABLE `recetasproducto`
  ADD CONSTRAINT `fk_recetasproducto_productostbl1` FOREIGN KEY (`productostbl_id`) REFERENCES `productostbl` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_recetasproducto_recetastbl1` FOREIGN KEY (`recetastbl_id`) REFERENCES `recetastbl` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `recetastbl`
--
ALTER TABLE `recetastbl`
  ADD CONSTRAINT `fk_recetastbl_usuariostbl1` FOREIGN KEY (`usuariostbl_id`) REFERENCES `usuariostbl` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuariostbl`
--
ALTER TABLE `usuariostbl`
  ADD CONSTRAINT `fk_usuariostbl_rolestbl1` FOREIGN KEY (`rolestbl_id`) REFERENCES `rolestbl` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
